    </div> <!-- Close container -->

    <footer class="footer mt-auto py-4 bg-dark text-light">
        <div class="container">
            <div class="text-center">
                <p class="mb-0">
                    &copy; <?= date('Y') ?> TodoApp. All rights reserved.
                </p>
            </div>
        </div>
    </footer>

    <script src="<?= BASE_URL ?>js/script.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>