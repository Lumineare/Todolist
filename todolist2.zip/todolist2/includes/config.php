<?php
// Pastikan tidak ada karakter/spasi sebelum tag pembuka PHP

// Error reporting untuk development
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Session handling
if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'cookie_lifetime' => 86400,
        'cookie_secure' => false, // Ubah ke true jika menggunakan HTTPS
        'cookie_httponly' => true,
        'use_strict_mode' => true
    ]);
}

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'todo_db');
define('BASE_URL', 'http://localhost/todolist/');

// Database connection
try {
    $koneksi = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $koneksi->set_charset("utf8mb4");
} catch (Exception $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Security functions
function sanitize($data) {
    global $koneksi;
    return htmlspecialchars($koneksi->real_escape_string(trim($data)));
}

function redirect($url) {
    header("Location: " . BASE_URL . $url);
    exit();
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}