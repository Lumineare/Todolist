<?php
require_once __DIR__ . '/../includes/config.php';

// Validasi request dan CSRF Token
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['csrf_token']) && hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    
    // Hapus semua data sesi
    $_SESSION = array();

    // Hapus cookie sesi
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params["path"],
            $params["domain"],
            $params["secure"],
            $params["httponly"]
        );
    }

    // Hancurkan dan regenerasi sesi
    session_destroy();
    session_start();
    session_regenerate_id(true);
    
    // Set header keamanan
    header("Content-Security-Policy: default-src 'self'");
    header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
    header("Location: " . BASE_URL . "auth/login.php");
    exit();
}

// Redirect jika akses tidak valid
redirect('login.php');